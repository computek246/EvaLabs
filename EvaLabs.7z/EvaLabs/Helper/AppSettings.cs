﻿namespace EvaLabs.Helper
{
    public class AppSettings
    {
        public string Secret { get; set; }
    }
}
