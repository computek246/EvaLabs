﻿using AutoMapper;
using EvaLabs.ViewModels.City;

namespace EvaLabs.Helper.Mapping.Profiles
{
    public class MappingProfile : Profile
    {
        public MappingProfile()
        {
            
        }
    }
}
