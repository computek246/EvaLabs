﻿namespace EvaLabs.ViewModels.Common
{
    public class FilterVm : BaseModelVm
    {
    }
}