using FluentValidation;

namespace EvaLabs.ViewModels.City
{
    public class CityVmValidator : AbstractValidator<CityVm>
    {
        public CityVmValidator()
        {
            
        }
    }
}