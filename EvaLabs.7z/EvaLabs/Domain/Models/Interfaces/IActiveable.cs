﻿namespace EvaLabs.Domain.Models.Interfaces
{
    public interface IActiveable
    {
        bool IsActive { get; set; }
    }
}