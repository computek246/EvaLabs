﻿namespace EvaLabs.Security.Enums
{
    public enum UserType
    {
        Employee,
        Customer
    }
}